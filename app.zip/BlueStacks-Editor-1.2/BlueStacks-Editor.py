import json
import os
import platform
import re
import shutil
from pathlib import Path
import customtkinter as ctk

class BlueStacksEditor(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.setup_window()
        self.load_configs()
        self.create_main_ui()
        
    def setup_window(self):
        """Initialize window settings"""
        self.title("BlueStacks-Editor 1.0")
        self.geometry("350x600+50+50")
        self.attributes('-topmost', True)
        ctk.set_appearance_mode("Dark")
        
    def load_configs(self):
        """Load all configuration files"""
        try:
            with open('menu.json', 'r') as f:
                self.menu_data = json.load(f)
            with open('patches.json', 'r') as f:
                self.patches_data = json.load(f)
            with open('config.json', 'r') as f:
                self.config_data = json.load(f)
            with open('exe.json', 'r') as f:
                self.assets = json.load(f)
        except FileNotFoundError as e:
            print(f"❌ Config file missing: {e}")
            self.destroy()

    def show_dialog(self, title, message, is_error=False):
        dialog = ctk.CTkToplevel(self)
        dialog.title(title)
        dialog.geometry("300x150")
        dialog.attributes('-topmost', True)

        color = "red" if is_error else "green"

        label = ctk.CTkLabel(dialog, text=f"{message}", text_color=color)
        label.pack(pady=20)
        
        button = ctk.CTkButton(dialog, text="OK", command=dialog.destroy)
        button.pack(pady=10)

        if not is_error:
            dialog.after(3000, dialog.destroy)

    def create_main_ui(self):
        """Create the main UI components"""
        # Header
        title = ctk.CTkLabel(self, text=self.menu_data['title'], font=("Arial", 20, "bold"))
        title.pack(pady=10)
        
        subtitle = ctk.CTkLabel(self, text=self.menu_data['subtitle'], font=("Arial", 12))
        subtitle.pack(pady=5)
        
        note = ctk.CTkLabel(self, text=self.menu_data['visiblenote'], text_color="green")
        note.pack(pady=5)
        
        # Dynamic menu
        for category in self.menu_data['menu']:
            if category.get('level') == 1:
                self.create_category_section(category)
    
    def create_category_section(self, category):
        """Create an expandable category section"""
        category_frame = ctk.CTkFrame(self)
        category_frame.pack(fill="x", padx=10, pady=5)
        
        header = ctk.CTkButton(
            category_frame,
            text=f"📁 {category['title']}",
            command=lambda cat=category, frame=category_frame: self.toggle_category(frame, cat)
        )
        header.pack(fill="x", padx=5, pady=5)
    
    def toggle_category(self, parent_frame, category):
        """Toggle category expansion and create child elements"""
        # Clear previous children
        for widget in parent_frame.winfo_children()[1:]:
            widget.destroy()
            
        if not hasattr(parent_frame, 'expanded') or not parent_frame.expanded:
            parent_frame.expanded = True
            children_frame = ctk.CTkFrame(parent_frame)
            children_frame.pack(fill="x", padx=10, pady=5)
            
            for child in category.get('children', []):
                if child.get('mapsto'):
                    self.create_patch_button(children_frame, child)
                elif child.get('children'):
                    self.create_subcategory_section(children_frame, child)
                elif child.get('value') is not None:
                    self.create_toggle_switch(children_frame, child)
                else:
                    self.create_action_button(children_frame, child)
        else:
            parent_frame.expanded = False
    
    def create_subcategory_section(self, parent_frame, child_config):
        """Create nested subcategory (for backup config, etc.)"""
        sub_frame = ctk.CTkFrame(parent_frame)
        sub_frame.pack(fill="x", padx=5, pady=2)
        
        sub_header = ctk.CTkButton(
            sub_frame,
            text=f"⚙️ {child_config['title']}",
            command=lambda cfg=child_config, frame=sub_frame: self.toggle_subcategory(frame, cfg)
        )
        sub_header.pack(fill="x", padx=5, pady=2)
    
    def toggle_subcategory(self, parent_frame, child_config):
        """Toggle subcategory expansion"""
        for widget in parent_frame.winfo_children()[1:]:
            widget.destroy()
            
        if not hasattr(parent_frame, 'sub_expanded') or not parent_frame.sub_expanded:
            parent_frame.sub_expanded = True
            for nested_child in child_config.get('children', []):
                if nested_child.get('value') is not None:
                    self.create_toggle_switch(parent_frame, nested_child)
        else:
            parent_frame.sub_expanded = False
    
    def create_patch_button(self, parent_frame, child_config):
        """Create a button that applies patches"""
        button = ctk.CTkButton(
            parent_frame,
            text=child_config['title'],
            command=lambda cfg=child_config: self.handle_patch_click(cfg)
        )
        button.pack(fill="x", padx=5, pady=2)
    
    def handle_patch_click(self, child_config):
        """Handle patch button clicks"""
        patch_data = self.resolve_mapsto(child_config['mapsto'])
        if patch_data:
            if patch_data.get('to') == "" or patch_data.get('from') == "":
                user_value = self.ask_for_input(patch_data['name'])
                if user_value:
                    self.apply_patch(patch_data, user_value)
            else:
                self.apply_patch(patch_data)
        else:
            self.show_dialog("RuntimeError:",f"❌ Could not resolve:, {child_config['mapsto']}",True)
    
    def create_toggle_switch(self, parent_frame, child_config):
        """Create toggle switches for settings"""
        switch_var = ctk.BooleanVar(value=child_config.get('value', False))
        
        switch = ctk.CTkSwitch(
            parent_frame,
            text=child_config['title'],
            variable=switch_var,
            command=lambda cfg=child_config, var=switch_var: self.handle_toggle(cfg, var)
        )
        switch.pack(fill="x", padx=5, pady=2)
    
    def handle_toggle(self, child_config, switch_var):
        """Handle toggle switch changes"""
        print(f"🔧 {child_config['title']} set to: {switch_var.get()}")
        # Save to user settings (implement later)
    
    def create_action_button(self, parent_frame, child_config):
        """Create action buttons (backups, etc.)"""
        button = ctk.CTkButton(
            parent_frame,
            text=child_config['title'],
            command=lambda cfg=child_config: self.handle_action_click(cfg)
        )
        button.pack(fill="x", padx=5, pady=2)
    
    def handle_action_click(self, child_config):
        """Handle action button clicks"""
        action = child_config['title']
        if "Backup" in action:
            if "View" in action:
                self.show_backup_list()
            elif "Load" in action:
                self.load_backup_dialog()
            elif "Delete" in action:
                self.delete_backup_dialog()
    
    def ask_for_input(self, prompt, default_value=""):
        """Get user input for patches that need values"""
        dialog = ctk.CTkInputDialog(text=f"{prompt}:", title="Input Required")
        return dialog.get_input() or default_value
    
    def resolve_mapsto(self, mapsto_string):
        """Resolve mapsto strings to patch data"""
        parts = mapsto_string.split(".")
        patch_group = parts[0]
        field_type = parts[1]
        field_num = int(parts[2])  # Fixed: convert to int
        
        for group in self.patches_data['patches']:
            if group['patchGroupName'] == patch_group:
                for field in group['fields']:
                    if field['field'] == field_num:
                        return field
        return None
    
    def locate_bluestacks_config(self):
        """Find Bluestacks installation path"""
        for path in self.config_data['Configs']['expectedInstallPaths']:
            if os.path.exists(path):
                return path
        return None
    
    def apply_patch(self, patch_config, user_value=None):
        """Apply a patch to Bluestacks config"""
        config_path = self.locate_bluestacks_config()
        if not config_path:
            self.show_dialog("RuntimeError","❌ Bluestacks installation not found!",True)
            return False
        
        print(f"📍 Bluestacks path: {config_path}")
    
        # Use the main config file from your config.json
        config_file = self.config_data['Configs']['mainBlueStacksConfig']
        target_file = os.path.join(config_path, config_file)
    
        print(f"🎯 Target config: {target_file}")
    
        # Handle multiple IDs (like ad removal super patch)
        target_ids = patch_config.get('ids', [patch_config['id']])
    
        success = True
        for config_id in target_ids:
            print(f"\n--- Patching {config_id} ---")
            result = self.modify_config_file(target_file, config_id, patch_config, user_value)
            if not result:
                success = False
    
        return success

    def modify_config_file(self, file_path, config_id, patch_config, user_value):
        """DEBUG VERSION - Let's see what the fuck is actually happening"""
        print(f"🎯 Attempting to patch: {config_id}")
        print(f"📁 File: {file_path}")
    
        if not os.path.exists(file_path):
            self.show_dialog("RuntimeError:",f"❌ File does not exist: {file_path}",True)
            return False
        
    # READ AND PRINT THE ACTUAL CONTENT
        try:
            with open(file_path, 'r') as f:
                content = f.read()
                print("=== ACTUAL FILE CONTENT ===")
                for i, line in enumerate(content.split('\n'), 1):
                    if config_id in line:
                        print(f"LINE {i}: {repr(line)}")  # repr shows hidden chars
                print("=== END FILE CONTENT ===")
        except Exception as e:
            self.show_dialog("RuntimeError",f"❌ Cannot read file: {e}",True)
            return False
    
        new_value = user_value or patch_config.get('to', '')
        old_value = patch_config.get('from', '')
    
        print(f"🔄 Want to change: '{old_value}' → '{new_value}'")
    
    # LET'S TRY EVERY POSSIBLE FORMAT
        test_patterns = [
            f'{config_id} = "{old_value}"',
            f'{config_id}="{old_value}"', 
            f'{config_id} = {old_value}',
            f'{config_id}={old_value}',
            f'{config_id} = \'{old_value}\'',
            f'{config_id}=\'{old_value}\'',
        ]
    
        print("🔍 Testing patterns:")
        for pattern in test_patterns:
            if pattern in content:
                self.show_dialog("Success:",f"   ✅ FOUND: {repr(pattern)}")
            else:
                print(f"   ❌ NOT FOUND: {repr(pattern)}")
    
    # NOW LET'S JUST DO A SIMPLE SEARCH AND REPLACE
        lines = content.split('\n')
        changed = False
    
        for i, line in enumerate(lines):
            if config_id in line:
                print(f"🎯 Found target line {i}: {repr(line)}")
            
            # Try to replace any occurrence of old_value with new_value in this line
                original_line = line
                if f'="{old_value}"' in line:
                    line = line.replace(f'="{old_value}"', f'="{new_value}"')
                    print(f"   ✅ Replaced quoted version")
                elif f'={old_value}' in line:
                    line = line.replace(f'={old_value}', f'={new_value}')
                    print(f"   ✅ Replaced unquoted version")
                elif f'= "{old_value}"' in line:
                    line = line.replace(f'= "{old_value}"', f'= "{new_value}"')
                    print(f"   ✅ Replaced spaced quoted version")
            
                if line != original_line:
                    lines[i] = line
                    changed = True
                    print(f"   🔄 New line: {repr(line)}")
                    break
    
        if changed:
            try:
                new_content = '\n'.join(lines)
                with open(file_path, 'w') as f:
                    f.write(new_content)
                self.show_dialog("Success", f"✅ SUCCESS: File rewritten with changes")
            
            # VERIFY
                with open(file_path, 'r') as f:
                    verify_content = f.read()
                    if f'="{new_value}"' in verify_content or f'={new_value}' in verify_content:
                        self.show_dialog("Verefier:", f"🔍 VERIFIED: Change is in file!")
                        return True
                    else:
                        self.show_dialog("RuntimeError","❌ VERIFICATION FAILED - change not persisted",True)
                        return False
                    
            except Exception as e:
                self.show_dialog("RuntimeError:",f"❌ Cannot write file: {e}",True)
                return False
        else:
            self.show_dialog("RuntimeError:","❌ No changes could be made to any line or patch already applied",True)
            return False

    def show_backup_list(self):
        """Show available backups (placeholder)"""
        self.show_dialog("2","📂 Backup list feature coming soon!")
    
    def load_backup_dialog(self):
        """Load backup dialog (placeholder)"""
        self.show_dialog("2","🔄 Load backup feature coming soon!")
    
    def delete_backup_dialog(self):
        """Delete backup dialog (placeholder)"""
        self.show_dialog("2","🗑️ Delete backup feature coming soon!")

if __name__ == "__main__":
    app = BlueStacksEditor()
    app.mainloop()